#include <stdio.h>
main(){
	int x;
	printf("Enter 1 Number: ");
	scanf("%d",&x);
	int res=(x%2==0)?printf("%d is Even",x):printf("%d is Odd",x);
	return 0;
}
