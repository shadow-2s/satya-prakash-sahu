#include <stdio.h>
main(){
	int x,y,z;
	printf("Enter 1st out of 3 Numbers: ");
	scanf("%d",&x);
	printf("\nEnter 2nd out of 3 Numbers: ");
	scanf("%d",&y);
	printf("\nEnter 3rd out of 3 Numbers: ");
	scanf("%d",&z);
	int res=(x>y)?(x>z)?x:z:(y>z)?y:z;
	printf("\nlargest number is: %d", res);
	return 0;
}
