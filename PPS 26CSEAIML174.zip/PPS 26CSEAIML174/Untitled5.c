#include <stdio.h>
main(){
	int x=2,y;
	y= ++x + ++x + x++;
	printf("x = %d y = %d\n ",x,y);
	return 0;
//	int x,y;
//	scanf("%d",&x);
//	y= ++x + ++x + x++;
//	printf("x = %d y = %d\n ",x,y);
//	return 0;

}
