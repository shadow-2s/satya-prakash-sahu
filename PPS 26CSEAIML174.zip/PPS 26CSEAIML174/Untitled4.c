#include <stdio.h>
int main(){
	int x,b[16],i=0,c=0;
	printf("Enter A Number: ");
	scanf("%d",x);
	printf("\nBinary number: ");
	while(x!=0){
		b[i]=x%2;
		x=x/2;
		i++;
	}
	while(c!=16){
		printf("%d",b[c]);
		c++;
	}
	return 0;
}
